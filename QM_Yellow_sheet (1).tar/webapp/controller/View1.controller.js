sap.ui.define([
    "sap/ui/core/mvc/Controller",
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
    "sap/ui/core/BusyIndicator",
    'sap/m/MessageToast'
], (Controller, Filter, FilterOperator,BusyIndicator, MessageToast) => {
    "use strict";

    return Controller.extend("com.wl.qm.zyellowsheet.controller.View1", {
        onInit() {
        },
    
        onnumeroValueHelp: function () {
            var sPlant = this.getView().byId("idtxtplant").getValue(); // Adjust "idtxtproduction" as needed
            // Check if a Plant has been entered
            if (!sPlant) {
                // Show an error message if the Plant is empty
                var oResourceModel = this.getView().getModel("i18n"),
    oBundle = oResourceModel.getResourceBundle();
sap.m.MessageToast.show(oBundle.getText("Yellow.controller_error"));

                // MessageToast.show("Please enter a Plant before selecting Process order.");
                return; // Stop further execution if no Plant is provided
            }

            var bValidPlant = this.getOwnerComponent().getModel("local").getProperty("/validplant");
            if(bValidPlant){
                this._openPOVH(sPlant);
            }
            else{
                 // Show an error message if the Plant is empty
                 var oResourceModel = this.getView().getModel("i18n"),
    oBundle = oResourceModel.getResourceBundle();
sap.m.MessageToast.show(oBundle.getText("Yellow.Plant_invalid"));

                //  MessageToast.show("Not a valid plant");
            }


        },

        _openPOVH: function(sPlant){
            var oView = this.getView();
                    // Check if the Plant dialog has already been created
                    if (!this.oProductionOrder) {
                        // Create the dialog from the XML fragment and bind it to the controller
                        this.oProductionOrder = sap.ui.xmlfragment("com.wl.qm.zyellowsheet.fragment.ProcessOrder", this);
                        // Add the dialog as a dependent to the view
                        oView.addDependent(this.oProductionOrder);
                    }
                    // Create an array to hold filters for the Process order dialog
                    var aFilters = [];
                    // If a plant is provided, create a filter for it
                    if (sPlant) {
                        aFilters.push(new Filter("plant", FilterOperator.EQ, sPlant));
                    }

                    // Apply filters to the Scrap Data dialog
                    var oBinding = this.oProductionOrder.getBinding("items");
                    if (oBinding) {
                        // Apply the filters to the binding of the items in the dialog
                        oBinding.filter(aFilters);
                    }

                    // Open the Scrap Data dialog
                    this.oProductionOrder.open();
        },

        OnPlantChange: function(){
            this._validatePlant();
        },

        _validatePlant: function(){
            var sPlant = this.getView().byId("idtxtplant").getValue(); // Adjust "idtxtproduction" as needed
            // Check if a Plant has been entered
            if (!sPlant) {
                // Show an error message if the Plant is empty
                var oResourceModel = this.getView().getModel("i18n"),
    oBundle = oResourceModel.getResourceBundle();
sap.m.MessageToast.show(oBundle.getText("Yellow_plant_error"));
                // MessageToast.show("Please enter a Plant before selecting Process order.");
                return; // Stop further execution if no Plant is provided
            }

            var oModel = this.getOwnerComponent().getModel();
            oModel.read("/validate_plant", {
                filters: [
                    new Filter("plant", FilterOperator.EQ, sPlant)
                ],
                success: function (oData) {
                    if(oData && oData.results.length <= 0 ){
                        var oResourceModel = this.getView().getModel("i18n"),
    oBundle = oResourceModel.getResourceBundle();
sap.m.MessageToast.show(oBundle.getText("Yellow.Plant_invalid"));
                        // sap.m.MessageToast.show("Not a valid plant");
                        this.getOwnerComponent().getModel("local").setProperty("/validplant", false);
                        this.getOwnerComponent().getModel("local").setProperty("/aufnr", "");//clear the PO Data
                        return;
                    }
                    this.getOwnerComponent().getModel("local").setProperty("/validplant", true);
                    this.getOwnerComponent().getModel("local").setProperty("/aufnr", "")
                }.bind(this), // Bind the context to ensure 'this' refers to the controller
                error: function (oError) {
                    var oResourceModel = this.getView().getModel("i18n"),
    oBundle = oResourceModel.getResourceBundle();
sap.m.MessageToast.show(oBundle.getText("Yellow.plant"));
                    // sap.m.MessageToast.show("Failed to validate Plant details");
                    console.error(oError); // Log the error for debugging
                    this.getOwnerComponent().getModel("local").setProperty("/validplant", false);
                    this.getOwnerComponent().getModel("local").setProperty("/aufnr", "")
                }.bind(this)
            });

        },
        handleSearchYS: function (oEvent) {
            // Get the search value from the event parameter
            var sValue = oEvent.getParameter("value");

            // Create a filter that matches the process order with the search value
            var aFilter = new Filter({
                filters: [
                    new Filter("aufnr", FilterOperator.Contains, sValue), // Filter by aufnr
                ],
                and: false, // Allow matches for either filter
            });

            // Get the binding for the items in the search source
            var oBinding = oEvent.getSource().getBinding("items");
            // If the binding exists, apply the filter to it
            if (oBinding) {
                oBinding.filter([aFilter]); // Apply the filter array
            }
        },

        handleCloseYS: function (oEvent) {
            // Clear the selected plant in the local model
            this.getOwnerComponent().getModel("local");

            // Get the binding for the items in the event's source
            var oBinding = oEvent.getSource().getBinding("items");
            // If there is a binding, clear any applied filters
            if (oBinding) {
                oBinding.filter([]);
            }

            // Retrieve the selected contexts from the event
            var aContexts = oEvent.getParameter("selectedContexts");
            // Check if there are any selected contexts
            if (aContexts && aContexts.length) {
                var oProcessOrder = aContexts[0].getObject().aufnr;
                var oDataObj=aContexts[0].getObject();

                // Set the Production Order value in the input field
                this.byId("idtxtnumero").setValue(oProcessOrder);

                this.getOwnerComponent().getModel("local").setProperty("/aufnr", oProcessOrder);

                // Call the function to handle changes related to the Production Order
                this._setPOStatus(oDataObj);
            }
        },

        onnumeroChange: function(){
            //validate plant and then proceed with POStatus
            this._setPOStatus();
        },
        _setPOStatus: function (oDataObj) {

            if(oDataObj && oDataObj.status){
                this.getOwnerComponent().getModel("local").setProperty("/aufnr_status", oDataObj.status);
            }
            else{
                var sPO = this.getView().byId("idtxtnumero").getValue();
                var sPlant = this.getView().byId("idtxtplant").getValue();
                var oModel = this.getOwnerComponent().getModel();
                oModel.read("/process_order_data", {
                    filters: [ 
                        new Filter("plant", FilterOperator.EQ, sPlant),
                        new Filter("aufnr", FilterOperator.EQ, sPO)
                    ],
                    success: function (oData) {
                        if (oData && oData.results && oData.results.length > 0) {
                            this.getOwnerComponent().getModel("local").setProperty("/aufnr_status", oData.results[0].status);
                        } else {
                           console.log("No entries returned from API for Plant & PO Combo")
                        }
                    }.bind(this), // Bind the context to ensure 'this' refers to the controller
                    error: function (oError) {
                        var oResourceModel = this.getView().getModel("i18n"),
    oBundle = oResourceModel.getResourceBundle();
sap.m.MessageToast.show(oBundle.getText("Yellow_process_order"));

                        // sap.m.MessageToast.show("Failed to fetch PO Status details");
                        console.error(oError); // Log the error for debugging
                    }
                });
            }
            

        },

        onPrintPress: function () {
    // Implement print functionality here
    var sPlantKeyword = this.byId("idtxtplant").getValue(),
        sPO = this.byId("idtxtnumero").getValue(),
        sRif = this.byId("idtxtsearch").getValue(),
        sMaterial = this.byId("idtxtmaterial").getValue(),
        sImballo = this.byId("idtxtmballo").getValue(),
        sLinea = this.byId("idtxtlinea").getValue();
    var aFilter = []; // Declare aFilter with var

    // Check if any mandatory fields are empty and show an error message if so
    if (!sRif || !sMaterial || !sImballo || !sLinea) {
        var oResourceModel = this.getView().getModel("i18n"),
            oBundle = oResourceModel.getResourceBundle();
        sap.m.MessageToast.show(oBundle.getText("Yellow_mandatory_message"));

        // MessageToast.show("Please fill in the mandatory fields."); // Notify user
        return; // Exit the function if mandatory fields are missing
    }

    // Validation to check if the inputted PO is Released or not. If Released then will not be able to print and throw error
    if (this.getOwnerComponent().getModel("local").getProperty("/aufnr_status") === "REL") {
        var oResourceModel = this.getView().getModel("i18n"),
            oBundle = oResourceModel.getResourceBundle();
        sap.m.MessageToast.show(oBundle.getText("Yellow_stauts"));

        // MessageToast.show("Prod order is released cannot see the form"); // Notify user
        return; // Exit the function if mandatory fields are missing
    }

    // Show BusyIndicator
    sap.ui.core.BusyIndicator.show(0);

    // If validation checks are successful then proceed with displaying the form with the user inputted values
    if (sPlantKeyword) {
        aFilter.push(new Filter({
            path: "plant",
            operator: FilterOperator.EQ,
            value1: sPlantKeyword.toUpperCase()
        }));
    }
    if (sPO) {
        aFilter.push(new Filter({
            path: "aufnr",
            operator: FilterOperator.EQ,
            value1: sPO.toUpperCase()
        }));
    }
    if (sRif) {
        aFilter.push(new Filter({
            path: "rif",
            operator: FilterOperator.EQ,
            value1: sRif.toUpperCase()
        }));
    }
    if (sMaterial) {
        aFilter.push(new Filter({
            path: "nome_mat",
            operator: FilterOperator.EQ,
            value1: sMaterial.toUpperCase()
        }));
    }
    if (sImballo) {
        aFilter.push(new Filter({
            path: "imballo",
            operator: FilterOperator.EQ,
            value1: sImballo.toUpperCase()
        }));
    }
    if (sLinea) {
        aFilter.push(new Filter({
            path: "linea",
            operator: FilterOperator.EQ,
            value1: sLinea.toUpperCase()
        }));
    }
    this.getOwnerComponent().getModel("local").setProperty("/filterData", aFilter);
    this.getOwnerComponent().getModel().read("/yello_sheet_form", {
        filters: aFilter,
        success: function (oData) {
            // Bind the retrieved data to a model property
            this.getOwnerComponent().getModel("local").setProperty("/formData", oData);
            var receivedString = oData.results[0].formdata;
            this._convertBase64ToPDF(receivedString);

            // Hide BusyIndicator
            sap.ui.core.BusyIndicator.hide();
        }.bind(this),
        error: function (oError) {
            // Handle error
            var oResourceModel = this.getView().getModel("i18n"),
                oBundle = oResourceModel.getResourceBundle();
            sap.m.MessageToast.show(oBundle.getText("Yellow_message"));
            // MessageToast.show("Error retrieving form data.");

            // Hide BusyIndicator
            sap.ui.core.BusyIndicator.hide();
        }
    });
},

_convertBase64ToPDF: function (base64String) {
    const byteCharacters = atob(base64String);    //to decode
    const byteNumbers = new Array(byteCharacters.length);  // array of 8 bits
    for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: 'application/pdf' }); //unknown blob

    var _pdfurl = URL.createObjectURL(blob);

    if (!this._PDFViewer) {
        this._PDFViewer = new sap.m.PDFViewer({
            width: "auto",
            source: _pdfurl // my blob url
        });
        jQuery.sap.addUrlWhitelist("blob"); // register blob url as whitelist
    }
    this._PDFViewer.downloadPDF = function () {
        var link = document.createElement('a');
        link.href = _pdfurl;
        link.download = sFileName;
        link.style.display = 'none';
        document.body.appendChild(link);

        // Trigger a click event on the anchor element
        link.click();

        // Clean up
        document.body.removeChild(link);
    };
    this._PDFViewer.open();
},
        onAfterRendering: function(){
            //validate the plant value which is default
            this._validatePlant();
        },

        _POStatusCheck: function(){

        }

    });
});
